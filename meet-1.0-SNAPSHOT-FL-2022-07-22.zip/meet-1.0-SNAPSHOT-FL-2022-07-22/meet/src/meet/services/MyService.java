package meet.services;

public interface MyService {

	String ask(String question);
}
